<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};


$modelID= $data_back->{"cv_id"};

$response = array(); 


if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
        $sql_data="SELECT sum(`quantity`) AS sold FROM `tbl_sinvoice_item` WHERE model_id=$modelID";
        $row_data = $con->query($sql_data); 
        $res_data = $row_data->fetch_object();
        $sold= $res_data->sold;
                
       
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                $response['sold'] = $sold;
                
           
                echo json_encode(array('modle_sold'=>$response));
                
 
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                
                    echo json_encode(array('modle_sold'=>$response));
                
                }
                
   
  ?>