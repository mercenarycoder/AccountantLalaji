<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$created_by= $data_back->{"created_by"};
$from= $data_back->{"from"};
$to= $data_back->{"to"};

$date_from= $data_back->{"date_from"};
$date_to= $data_back->{"date_to"};

$model_id= $data_back->{"model_id"};
$brand_id= $data_back->{"brand_id"};
$barcode= $data_back->{"barcode"};
$mode= $data_back->{"mode"};

$type= $data_back->{"type"};




$response = array(); 
$SaleListArray = array();


if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{

    $todayDate = date("Y-m-d");
    
            $sql_pm="SELECT * FROM tbl_account WHERE cmp_id=$cmp_id && account_name='$mode' && login_id=$login_id";
            $row_pm = $con->query($sql_pm); 
            $res_pm = $row_pm->fetch_object();
            $mode = $res_pm->id;
            
            if($mode==null){
                $mode = '';
            }

            $sql_modle="SELECT * FROM tbl_model WHERE cmp_id=$cmp_id && model_name='$model_id' && login_id=$login_id";
            $row_modle = $con->query($sql_modle); 
            $res_modle = $row_modle->fetch_object();
            $model_id = $res_modle->id;
            
            if($model_id==null){
                $model_id = '';
            }
            
            $sql_brand="SELECT * FROM tbl_brand WHERE cmp_id=$cmp_id && brand_name='$brand_id' && login_id=$login_id";
            $row_brand = $con->query($sql_brand); 
            $res_brand = $row_brand->fetch_object();
            $brand_id = $res_brand->id;
            
            if($brand_id==null){
                $brand_id = '';
            }

    
    
    
    if($type==='sale'){
    
    
 //   x x x x
    
    if($model_id=='' && $brand_id == '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'x x x x';
        
        $sqlQ = "SELECT tbl_sinvoice.*, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
        

    }
    
    //   y x x x
    
    if($model_id!='' && $brand_id == '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'y x x x';
        
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y x x
    
    if($model_id!='' && $brand_id != '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'y y x x';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y y x
    
     if($model_id!='' && $brand_id != '' && $barcode!='' && $mode=='' ){
        
        $queryRun = 'y y y x';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y y y
    
     if($model_id!='' && $brand_id != '' && $barcode!='' && $mode!='' ){
        
          $queryRun = 'y y y y';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && tbl_sinvoice.payment_mode=$mode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x y x x
    
    if($model_id=='' && $brand_id != '' && $barcode=='' && $mode=='' ){
        
         $queryRun = 'x y x x';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_brand.id=$brand_id && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x x y x
    
     if($model_id=='' && $brand_id == '' && $barcode!='' && $mode=='' ){
        
         
          $queryRun = 'x x y x';
          
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.bar_code=$barcode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x x x y
    
     if($model_id=='' && $brand_id == '' && $barcode=='' && $mode!='' ){
        
          $queryRun = 'x x x y';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_sinvoice.payment_mode=$mode  && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
     //   x x y y
    
     if($model_id=='' && $brand_id == '' && $barcode!='' && $mode!='' ){
        
         $queryRun = 'x x y y';
         
        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.bar_code=$barcode && tbl_sinvoice.payment_mode=$mode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x y y y
    
       if($model_id=='' && $brand_id != '' && $barcode!='' && $mode!='' ){

   $queryRun = 'x y y y';

        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && tbl_sinvoice.payment_mode=$mode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y x x y
    
      if($model_id!='' && $brand_id == '' && $barcode=='' && $mode!='' ){
          
           $queryRun = 'y x x y';

        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id &&  tbl_sinvoice.payment_mode=$mode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y x y y
    
    if($model_id!='' && $brand_id == '' && $barcode!='' && $mode!='' ){
        
         $queryRun = 'y x y y';

        $sqlQ = "SELECT tbl_sinvoice.*, tbl_sinvoice_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_sinvoice 
            INNER JOIN tbl_sinvoice_item ON tbl_sinvoice.id=tbl_sinvoice_item.tbl_sinvoice_id 
            INNER JOIN tbl_model ON tbl_sinvoice_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id 
            INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id &&  tbl_model.bar_code=$barcode && tbl_sinvoice.payment_mode=$mode && (tbl_sinvoice.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to";
    
    }




        $sql_data="SELECT sum(`grand_total`) AS grand_total FROM `tbl_sinvoice` 
        WHERE (bill_date BETWEEN '$date_from' AND '$date_to') && cmp_id =$cmp_id && admin_id =$login_id && created_by =$created_by && status ='active'";
        $row_data = $con->query($sql_data); 
        $res_data = $row_data->fetch_object();
        $grand_total= $res_data->grand_total;
       
          
       
        $sql_data2="SELECT COUNT(id) AS NumberOfRows FROM tbl_sinvoice 
        WHERE (bill_date BETWEEN '$date_from' AND '$date_to') && cmp_id =$cmp_id && admin_id =$login_id && created_by =$created_by && status ='active'";
        $row_data2 = $con->query($sql_data2); 
        $res_data2 = $row_data2->fetch_object();
        $NumberOfRows= $res_data2->NumberOfRows;



    }
    
    
    
    
    
    if($type==='purchase'){
        
        
          
 //   x x x x
    
    if($model_id=='' && $brand_id == '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'x x x x';
        
        $sqlQ = "SELECT tbl_pinvoic.*, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
        

    }
    
    //   y x x x
    
    if($model_id!='' && $brand_id == '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'y x x x';
        
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y x x
    
    if($model_id!='' && $brand_id != '' && $barcode=='' && $mode=='' ){
        
        $queryRun = 'y y x x';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y y x
    
     if($model_id!='' && $brand_id != '' && $barcode!='' && $mode=='' ){
        
        $queryRun = 'y y y x';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y y y y
    
     if($model_id!='' && $brand_id != '' && $barcode!='' && $mode!='' ){
        
          $queryRun = 'y y y y';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id && tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && tbl_pinvoic.payment_mode=$mode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x y x x
    
    if($model_id=='' && $brand_id != '' && $barcode=='' && $mode=='' ){
        
         $queryRun = 'x y x x';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_brand.id=$brand_id && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x x y x
    
     if($model_id=='' && $brand_id == '' && $barcode!='' && $mode=='' ){
        
         
          $queryRun = 'x x y x';
          
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.bar_code=$barcode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x x x y
    
     if($model_id=='' && $brand_id == '' && $barcode=='' && $mode!='' ){
        
          $queryRun = 'x x x y';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_pinvoic.payment_mode=$mode  && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
     //   x x y y
    
     if($model_id=='' && $brand_id == '' && $barcode!='' && $mode!='' ){
        
         $queryRun = 'x x y y';
         
        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.bar_code=$barcode && tbl_pinvoic.payment_mode=$mode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   x y y y
    
       if($model_id=='' && $brand_id != '' && $barcode!='' && $mode!='' ){

   $queryRun = 'x y y y';

        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_brand.id=$brand_id && tbl_model.bar_code=$barcode && tbl_pinvoic.payment_mode=$mode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y x x y
    
      if($model_id!='' && $brand_id == '' && $barcode=='' && $mode!='' ){
          
           $queryRun = 'y x x y';

        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id &&  tbl_pinvoic.payment_mode=$mode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
    
    //   y x y y
    
    if($model_id!='' && $brand_id == '' && $barcode!='' && $mode!='' ){
        
         $queryRun = 'y x y y';

        $sqlQ = "SELECT tbl_pinvoic.*, tbl_pinvoic_item.id as inv_item_id, tbl_model.id as model_id,bar_code, tbl_brand.id as brand_id, customers.customer_name,customer_mobile , tbl_account.account_name as mode FROM tbl_pinvoic 
            INNER JOIN tbl_pinvoic_item ON tbl_pinvoic.id=tbl_pinvoic_item.invoice_id 
            INNER JOIN tbl_model ON tbl_pinvoic_item.model_id=tbl_model.id 
            INNER JOIN tbl_brand ON tbl_model.brand_id=tbl_brand.id 
            INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id 
            INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id 
            WHERE tbl_model.id=$model_id &&  tbl_model.bar_code=$barcode && tbl_pinvoic.payment_mode=$mode && (tbl_pinvoic.bill_date BETWEEN '$date_from' AND '$date_to') && tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1 ORDER BY id DESC LIMIT $from,$to";
    
    }
        
         $sql_data="SELECT sum(`grand_total`) AS grand_total FROM `tbl_pinvoic` 
        WHERE (bill_date BETWEEN '$date_from' AND '$date_to') && cmp_id =$cmp_id && admin_id =$login_id && created_by =$created_by && status ='active'";
        $row_data = $con->query($sql_data); 
        $res_data = $row_data->fetch_object();
        $grand_total= $res_data->grand_total;
       
          
       
        $sql_data2="SELECT COUNT(id) AS NumberOfRows FROM tbl_pinvoic 
        WHERE (bill_date BETWEEN '$date_from' AND '$date_to') && cmp_id =$cmp_id && admin_id =$login_id && created_by =$created_by && status ='active'";
        $row_data2 = $con->query($sql_data2); 
        $res_data2 = $row_data2->fetch_object();
        $NumberOfRows= $res_data2->NumberOfRows;
        
        
        
    }
    
    
    
    
        if ($result_SL = $con->query($sqlQ)) {
    
        while($row_SL = $result_SL->fetch_array(MYSQLI_ASSOC)) {
            $SaleListArray[] = $row_SL;
        }
        
        
        
        $response['error'] = TRUE;
        $response['error_msg'] = 'success';
        $response['Query'] = $queryRun;
        $response['all_amount'] = $grand_total;
        $response['all_bill'] = $NumberOfRows;
        
        $response['salelist_array'] = $SaleListArray;
        
        
        echo json_encode(array('salelist_data'=>$response));
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = $con->error;
        echo json_encode(array('salelist_data'=>$response));
    }
     
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = 'Failed';
        echo json_encode(array('salelist_data'=>$response));
    }
?>