<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};

$cate = $data_back->{"cate"};
$HSN = $data_back->{"HSN"};
$unit = $data_back->{"unit"};
$cast = $data_back->{"cast"};

$ProName = $data_back->{"ProName"};
$ProSpeci = $data_back->{"ProSpeci"};

$ProMOP = $data_back->{"ProMOP"};
$ProPP = $data_back->{"ProPP"};
$newPP = $data_back->{"newPP"};
$newMOP = $data_back->{"newMOP"};

$ProBarcode = $data_back->{"ProBarcode"};
$status = $data_back->{"status"};
$imagess = $data_back->{"imagess"};

$response=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
    
    $random = substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', mt_rand(1,30))),1,30);
$pic = $random.'.jpg';
    
    //$sql_st="SELECT * FROM tbl_bank WHERE bank_name	='$atype'";
   // $row_st = $con->query($sql_st);
   // $res_st = $row_st->fetch_object();
   // $id = $res_st->id;
   
    $date = date('Y-m-d h:i:s', time());
   
   if($imagess==='null'){
       
       $sql = "INSERT INTO tbl_model (login_id, brand_id, cmp_id, hsn_id, unit_id, cast_id, model_name, model_image, model_specialization,image, model_mop, model_mrp, model_pp, model_pp_new, model_mop_new, model_stock, bar_code, bar_code_status, model_status,updated_at,deleted_at)
                VALUES
                ($login_id, $cate, $cmp_id , $HSN, $unit, $cast, '$ProName', 'images.jpg', '$ProSpeci','', '$ProMOP', '',  '$ProPP', '$newPP', '$newMOP', '0', '$ProBarcode', '1', '$status','$date','$date')";
        
   }else{
       
        $sql = "INSERT INTO tbl_model (login_id, brand_id, cmp_id, hsn_id, unit_id, cast_id, model_name, model_image, model_specialization,image, model_mop, model_mrp, model_pp, model_pp_new, model_mop_new, model_stock, bar_code, bar_code_status, model_status,updated_at,deleted_at)
                VALUES
                ($login_id, $cate, $cmp_id , $HSN, $unit, $cast, '$ProName', '$pic', '$ProSpeci','', '$ProMOP', '',  '$ProPP', '$newPP', '$newMOP', '0', '$ProBarcode', '1', '$status','$date','$date')";
        
                $upload_path = "../images/$random.jpg";
				
				file_put_contents($upload_path, base64_decode($imagess));
				
   }
   
    
                
                    if ($con->query($sql) === TRUE) {
                        
                        
                        $response["error"]=TRUE; 
                        $response["error_msg"]='Success';
                        echo json_encode(array("newproduct"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("newproduct"=>$response)); 

                        }
            
           

}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("newproduct"=>$response));
}

    
    











?>