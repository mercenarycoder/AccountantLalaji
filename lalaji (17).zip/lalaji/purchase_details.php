<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};

$response = array(); 
$CusArray = array();
$ProductArray = array();
$PaymentArray = array();
$StateArray = array();



if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    
            $sql3="SELECT * FROM tbl_sinvoice WHERE cmp_id=$cmp_id && admin_id=$login_id ORDER BY id DESC LIMIT 1 ";
            $row3 = $con->query($sql3); 
            
            if($row3->num_rows > 0){
                
                $res3 = $row3->fetch_assoc();
                $bill_no = $res3["bill_no"];

                $numbers = preg_replace('/[^0-9]/', '', $bill_no);
                $letters = preg_replace('/[^a-zA-Z]/', '', $bill_no);
                
                $billNum = $numbers + 1; 
                $billno = $letters . $billNum;
                
                
            }else{
                
            $sql4="SELECT * FROM tbl_cmp WHERE id=$cmp_id && login_id=$login_id";
            $row4 = $con->query($sql4); 
            $res4 = $row4->fetch_object();
            $invoice_prefix= $res4->invoice_prefix;
            $invoice_prefix_serial= $res4->invoice_prefix_serial;
            $billno = $invoice_prefix . $invoice_prefix_serial;
            
            }
    


                if ($result3 = $con->query("SELECT * FROM customers WHERE cmp_id =$cmp_id && login_id =$login_id && customer_type ='vendor' && status ='active'")) {

                    while($row3 = $result3->fetch_array(MYSQLI_ASSOC)) {
                        $CusArray[] = $row3;
                    }
                }
                
                
            
                if ($result4 = $con->query("SELECT tbl_model.*, tbl_brand.brand_name, tbl_hsn.hsn_rate,hsn_code FROM tbl_model 
                INNER JOIN tbl_brand ON tbl_model.brand_id = tbl_brand.id
                INNER JOIN tbl_hsn ON tbl_model.hsn_id = tbl_hsn.id WHERE tbl_model.cmp_id =$cmp_id && tbl_model.login_id =$login_id && tbl_model.model_status ='active'")) {

                    while($row4 = $result4->fetch_array(MYSQLI_ASSOC)) {
                        $ProductArray[] = $row4;
                    }
                }
                
                
                if ($result4 = $con->query("SELECT * FROM tbl_account WHERE cmp_id =$cmp_id && login_id =$login_id && account_type =2 && status ='active'")) {

                    while($row4 = $result4->fetch_array(MYSQLI_ASSOC)) {
                        $PaymentArray[] = $row4;
                    }
                }
                
                if ($result5 = $con->query("SELECT * FROM tbl_state")) {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $StateArray[] = $row5;
                    }   
                }
                
                
   
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                $response['billno'] = $billno;
                $response['totalStock'] = $totalStock;
                $response['totalAmount'] = $totalAmount;
                
                $response['cus_array'] = $CusArray;
                $response['product_array'] = $ProductArray;
                $response['payment_array'] = $PaymentArray;
                $response['state_array'] = $StateArray;

                echo json_encode(array('sale_data'=>$response));
   
}
   
  ?>