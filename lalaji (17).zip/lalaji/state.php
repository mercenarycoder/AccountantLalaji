<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key= $data_back->{"auth_key"};

$response = array(); 
$StateArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    if ($result5 = $con->query("SELECT * FROM tbl_state")) {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $StateArray[] = $row5;
                    }
                
        
        $response['error'] = TRUE;
        $response['error_msg'] = 'success';
        $response['state_data'] = $StateArray;
        echo json_encode(array('state'=>$response));
        
    }else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = $con->error;
        echo json_encode(array('state'=>$response));
    }
     
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = 'Failed';
        echo json_encode(array('state'=>$response));
    }
      

?>