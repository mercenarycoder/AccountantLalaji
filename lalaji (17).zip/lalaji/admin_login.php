<?php


/*
include('config.php');

$json_data = json_decode(file_get_contents('php://input'));

$id=$json_data->{"id"};
$pass=$json_data->{"pass"};

    

    //$query = "SELECT * FROM `tbl_cmp_user_login` WHERE user_email='$id' or customer_mobile='$id' and user_pass='$pass' and customer_type='member'";
    
    $query = "SELECT * FROM `tbl_cmp_user_login` WHERE user_email='$id' and user_pass='$pass' and user_role='admin' or user_role='staff' and user_status='active'";
    
    $result = mysqli_query($con,$query) or die(mysql_error());
    $rows = mysqli_num_rows($result);
    $row = $result->fetch_assoc();
    $storeID = $row["store_id"];
    $login_id = $row["login_id"];
    
    $sql3="SELECT * FROM tbl_cmp WHERE id=$login_id";
    $result3 = mysqli_query($con,$sql3);
    $row3 = $result3->fetch_assoc();
    $cmp_name = $row3["firm_name"];
    $cmp_logo = $row3["cmp_logo"];
    
    
    $sql2="SELECT * FROM tbl_stores WHERE id=$storeID && status='active'";
    $result2 = mysqli_query($con,$sql2);
    $row2 = $result2->fetch_assoc();
    $cmp_id = $row2["cmp_id"];
    
    $response = array(); 
    $CusArray = array();
    $ProductArray = array();
    $PaymentArray = array();

    if($rows==1){
        
        $auth_key = substr(str_shuffle("0123456789abcdefghijklmnopqrstvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 32);
        
            $sql = "UPDATE tbl_cmp_user_login SET auth_key='$auth_key' WHERE user_email='$id' and user_pass='$pass' and user_role='admin' and user_status='active'";

            if ($con->query($sql) === TRUE) {
                
        
                

                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                $response['auth_key'] = $auth_key;
                $response['id'] = $row["id"];
                $response['store_id'] = $row["store_id"];
                $response['cmp_id'] = $cmp_id;
                
                $response['login_id'] = $row["login_id"]; 
                $response['user_name'] = $row["user_name"];
                $response['user_email'] = $row["user_email"];
                $response['user_mobile'] = $row["user_mobile"];
                $response['user_address'] = $row["user_address"];
                $response['user_role'] = $row["user_role"];
                $response['cmp_name'] = $cmp_name;
                $response['cmp_logo'] = $cmp_logo;
                
                

                echo json_encode(array('admin_login'=>$response));
               
            } else {
                
                $response['error'] = FALSE;
                $response['error_msg'] = 'Failed to generate auth_key';
                echo json_encode(array('admin_login'=>$response));
            }
                 
    } else {
                
                $response['error'] = FALSE;
                $response['error_msg'] = 'Check Login id and password';
                echo json_encode(array('admin_login'=>$response));
            }
*/
?>