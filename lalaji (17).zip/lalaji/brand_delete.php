<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};

$cv_id= $data_back->{"cv_id"};

$response = array(); 

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
                $sqluw = "UPDATE tbl_brand SET status='deactive' WHERE id=$cv_id";
                if (mysqli_query($con, $sqluw)) {
        
		        $response["error"]=TRUE; 
                $response["error_msg"]='Success';
                echo json_encode(array("brand_delete"=>$response));
	
	            }else{
	            $response["error"]=FALSE;
                $response["error_msg"]=$con->error;
                echo json_encode(array("brand_delete"=>$response));
	            }

        
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
        
                    echo json_encode(array('brand_delete'=>$response));
                
                }
                
   
  ?>