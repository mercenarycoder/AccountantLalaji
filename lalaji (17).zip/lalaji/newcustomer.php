<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};
$name = $data_back->{"name"};
$mob = $data_back->{"mob"};
$email = $data_back->{"email"};
$adds = $data_back->{"add"};
$state = $data_back->{"state"};
$bname = $data_back->{"bname"};
$gst = $data_back->{"gst"};
$type = $data_back->{"type"};


$response=array();
$CustomerDataArray=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
    //  && login_id==30 && cmp_id==30 && customer_type=='member'
    
    
    $sql_st="SELECT * FROM tbl_state WHERE state_name='$state'";
    $row_st = $con->query($sql_st);
    $res_st = $row_st->fetch_object();
    $state_id = $res_st->id;
           
    
    $sqlc = "SELECT * FROM customers WHERE customer_mobile='$mob' && login_id=$login_id && cmp_id=$cmp_id && customer_type='$type'";
    $resultc = $con->query($sqlc);
    
        if ($resultc->num_rows > 0) {
            $response["error"]=FALSE;
            $response["error_msg"]='Mobile no. already exist';
            echo json_encode(array("signup"=>$response));
        
        }else{
        
            if($email === NULL or $email ==='') {
            
            
                $sql = "INSERT INTO customers (login_id, cmp_id, customer_name, customer_type, email, password, shipping_address, state_id, customer_gst, customer_mobile, status, buss_name)
                VALUES
                ($login_id, $cmp_id , '$name', '$type', '$email', '', '$adds', $state_id, '$gst', '$mob', 'active', '$bname')";
        
                    if ($con->query($sql) === TRUE) {
                        
                        
                        $sql3="SELECT * FROM customers WHERE login_id=$login_id && cmp_id=$cmp_id ORDER BY id DESC LIMIT 1 ";
                        $row3 = $con->query($sql3); 
                        if($row3->num_rows > 0){
                        $res3 = $row3->fetch_assoc();
                        $cid = $res3["id"];
                        }
                        
                      $sql23 = "INSERT INTO tbl_open_account_cv (cv_id, total_amount, paid_amount, dues_amount, available_amount) VALUES ($cid, '0' , '0', '0', '0')";
                      if ($con->query($sql23) === TRUE) {
                    
                       }
           
                        $response["error"]=TRUE;
                        $response["error_msg"]='Success';
                    //  $response["error_msgrrrr"]=$adds;
                        echo json_encode(array("signup"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("signup"=>$response)); 

                        }
            
            
            }else{
            
                $sqle = "SELECT * FROM customers WHERE email='$email' && login_id=$login_id && cmp_id=$cmp_id && customer_type='$type'";
                $resulte = $con->query($sqle);
        
            if ($resulte->num_rows > 0) {
                $response["error"]=FALSE;
                $response["error_msg"]='Email id already exist';
                echo json_encode(array("signup"=>$response));
                }else{
            
        
  
                    $sql = "INSERT INTO customers (login_id, cmp_id, customer_name, customer_type, email, password, shipping_address, state_id, customer_gst, customer_mobile, status, buss_name)
                    VALUES
                    ($login_id, $cmp_id , '$name', '$type', '$email', '', '$adds', $state_id, '$gst', '$mob', 'active', '$bname')";
        
                        if ($con->query($sql) === TRUE) {
                            
                            
                            
                             
                        $sql3="SELECT * FROM customers WHERE login_id=$login_id && cmp_id=$cmp_id ORDER BY id DESC LIMIT 1 ";
                        $row3 = $con->query($sql3); 
                        if($row3->num_rows > 0){
                        $res3 = $row3->fetch_assoc();
                        $cid = $res3["id"];
                        }
                        
                      $sql23 = "INSERT INTO tbl_open_account_cv (cv_id, total_amount, paid_amount, dues_amount, available_amount) VALUES ($cid, '0' , '0', '0', '0')";
                      if ($con->query($sql23) === TRUE) {
                    
                       }
                            
                            
                            
           
                            $response["error"]=TRUE;
                            $response["error_msg"]='Success';
                          //  $response["error_msgrrrr"]=$adds;
                            echo json_encode(array("signup"=>$response));

           
                        } else {
                            $response["error"]=FALSE;
                            $response["error_msg"]= $con->error;
                            echo json_encode(array("signup"=>$response)); 

                        }
                }
            
            
            
        }
        
        

            }
}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("signup"=>$response));
}

    
    











?>