<?php

include('config.php');


$data_back = json_decode(file_get_contents('php://input'));
 
$auth_key= $data_back->{"auth_key"};
$login_id= $data_back->{"login_id"};
$cmp_id= $data_back->{"cmp_id"};
$cus_id= $data_back->{"cus_id"};
$user_id= $data_back->{"user_id"};
$billno= $data_back->{"billno"};
$bill_date= $data_back->{"date1"};

$igst= $data_back->{"igst"};
$cgst= $data_back->{"cgst"};
$sgst= $data_back->{"sgst"};

$total9= $data_back->{"total9"};
$total_paid= $data_back->{"totalpaid"};

$payment_mode= $data_back->{"paymentModeStr"};

$json_total_items= $data_back->{"json_total_items"};

$response = array();

if($auth_key == "sujeet@#$%999drv$#@%!^se44vwx35v")
{
   
    $resultbill = $con->query("SELECT id FROM tbl_pinvoic WHERE bill_no='$billno' && cmp_id=$cmp_id && admin_id=$login_id");
    
        if($resultbill->num_rows == 0) {
        
            $sql_pm="SELECT * FROM tbl_account WHERE cmp_id=$cmp_id && account_name='$payment_mode' && login_id=$login_id";
            $row_pm = $con->query($sql_pm); 
            $res_pm = $row_pm->fetch_object();
            $p_mode_id = $res_pm->id;
            $account_type = $res_pm->account_type;
    
   
            $sql2="SELECT * FROM customers WHERE id=$cus_id && login_id=$login_id";
            $row2 = $con->query($sql2); 
            $res2 = $row2->fetch_object();
            $admin_id= $res2->login_id;
           // $cmp_id= $res2->cmp_id;
            $wallet= $res2->wallet;
            
            $sql4="SELECT * FROM tbl_cmp WHERE id=$cmp_id && login_id=$login_id";
            $row4 = $con->query($sql4); 
            $res4 = $row4->fetch_object();
            $invoice_prefix= $res4->invoice_prefix;
             
            $sql3="SELECT * FROM tbl_pinvoic WHERE cmp_id=$cmp_id && admin_id=$login_id ORDER BY id DESC LIMIT 1 ";
            $row3 = $con->query($sql3); 
            
                if($row3->num_rows > 0){
                    $res3 = $row3->fetch_assoc();
                    $bill_no = $res3["bill_no"];

                    $numbers = preg_replace('/[^0-9]/', '', $bill_no);
                    $letters = preg_replace('/[^a-zA-Z]/', '', $bill_no);
                
                    $billNum = $numbers + 1; 
                    //  $billno = $letters . $billNum;
                
                
                }else{
                
                    $sql4="SELECT * FROM tbl_cmp WHERE id=$cmp_id && login_id=$login_id";
                    $row4 = $con->query($sql4); 
                    $res4 = $row4->fetch_object();
                    $invoice_prefix= $res4->invoice_prefix;
                    $invoice_prefix_serial= $res4->invoice_prefix_serial;
                    //  $billno = $invoice_prefix . $invoice_prefix_serial;
            
                }
            
            
            $elementCount  = count(json_decode($json_total_items, true));
            $ec = $elementCount-1;
            
            $item_g_t = '';
            $item_g_gst = '';
        
            for ($x = 0; $x <= $ec ; $x++) {
	
       					 $baz = json_decode($json_total_items,true);
       					 $item_id = ($baz[$x]['item_id']);
       					 $item_name = ($baz[$x]['item_name']);
       					 $item_rate = ($baz[$x]['item_rate']);
       					 $item_qua = ($baz[$x]['item_qua']);
       					 $item_amount = ($baz[$x]['item_amount']);
       					 
       					 $item_g_t = $item_g_t + $item_amount;
       					 
       					 
       					$sql5="SELECT * FROM tbl_model WHERE id=$item_id && login_id=$login_id";
                        $row5 = $con->query($sql5); 
                        $res5 = $row5->fetch_object();
                        $hsn_id = $res5->hsn_id;
                        
                        $sql6="SELECT * FROM tbl_hsn WHERE id=$hsn_id && login_id=$login_id";
                        $row6 = $con->query($sql6); 
                        $res6 = $row6->fetch_object();
                        $hsn_rate = $res6->hsn_rate;
                        
                        $item_pp = $item_rate - $item_rate * $hsn_rate / 100;
                        $item_gst = $item_rate - $item_pp;
                        
                        $item_gst = $item_gst * $item_qua;
                        $item_gst2 = $item_gst / 2;
                        
                        $item_g_gst = $item_g_gst + $item_gst2;
                        
                        
                        $sql7="SELECT * FROM tbl_account WHERE cmp_id=$cmp_id && account_name='$payment_mode' && login_id=$login_id";
                        $row7 = $con->query($sql7); 
                        $res7 = $row7->fetch_object();
                      //  $p_mode_id = $res7->id;            // 155  
                        
                        if ($result = $con->query("SELECT * FROM tbl_account WHERE cmp_id=$cmp_id && account_type=4 && login_id=$login_id" )) {

                			while($row = $result->fetch_array(MYSQLI_ASSOC)) {
                            $PamentModeArray[] = $row;
                            
                            
                            
                            
                			}
                        }
                        
                        
                        
                        
                        
       					 
        }
        
        
    //    if($payment_mode == 'Wallet'){
        
    //    $totalPaid = $item_g_t;
        
    //    $walletUB = $wallet - $totalPaid;
        
         //           $sql = "UPDATE customers SET wallet='$walletUB' WHERE id=$cus_id";
            //        $con->query($sql);
        
  //  }
    
   //     if($payment_mode == 'Cash on Delivery'){
        
    //    $totalPaid = '0';
        
   // }
        
        $date = date('Y-m-d h:i:s', time());
        
            
            
           // $ins="INSERT INTO tbl_sinvoice (admin_id,cmp_id,customer_id,created_by,bill_no,conn_type,reverse_charge,bill_date,igst,cgst,sgst,grand_total,total_paid,payment_option,payment_mode,flag_stock,emi_amount,location,status) VALUES ('27','27','234','0','NVI00','0','N','2018-05-28','0','0.0','0.0','111','222','1','144','1','0','room no 1','active')";
  
            $sql = "INSERT INTO tbl_pinvoic (admin_id, cmp_id, vendor_id, created_by, bill_no, bill_date, igst, cgst, sgst, grand_total, total_paid, payment_option, payment_mode, purchase_mode_status, status,updated_at,deleted_at) 
            VALUES
            ($admin_id,$cmp_id,$cus_id,$user_id,'$billno','$bill_date',$igst,$cgst,$sgst,'$total9','$total_paid',$account_type,$p_mode_id,'1','1','$date','$date')";
           
    		 if ($con->query($sql) === TRUE) {
    		     
    		$sql8="SELECT * FROM tbl_pinvoic WHERE cmp_id=$cmp_id && admin_id=$login_id ORDER BY id DESC LIMIT 1 ";
            $row8 = $con->query($sql8); 
        
            if($row8->num_rows > 0){
                $res8 = $row8->fetch_assoc();
                $tbl_sinvoice_id = $res8["id"];

            }
    		    
    		     
    		     for ($x = 0; $x <= $ec ; $x++) {
	
       					 $baz = json_decode($json_total_items,true);
       					 $item_id = ($baz[$x]['item_id']);
       					 $item_name = ($baz[$x]['item_name']);
       					 $item_rate = ($baz[$x]['item_rate']);
       					 $discount = ($baz[$x]['discount']);
       					 $item_qua = ($baz[$x]['item_qua']);
       					 $item_hsn = ($baz[$x]['item_hsn']);
       					 $item_amount = ($baz[$x]['item_amount']);
       					 
       					 
       					
       					 
       					$sql9="SELECT * FROM tbl_model WHERE id=$item_id && login_id=$login_id";
                        $row9 = $con->query($sql9); 
                        $res9 = $row9->fetch_object();
                        $hsn_id = $res9->hsn_id;
                        
                        $sql10="SELECT * FROM tbl_hsn WHERE id=$hsn_id && login_id=$login_id";
                        $row10 = $con->query($sql10); 
                        $res10 = $row10->fetch_object();
                        $hsn_rate = $res10->hsn_rate;
                        
                        $item_pp = $item_rate - $item_rate * $hsn_rate / 100;
                        $item_gst = $item_rate - $item_pp;
                        
                        $item_gst = $item_gst * $item_qua;
                        $item_gst2 = $item_gst / 2;
                        
                        $item_g_gst = $item_g_gst + $item_gst2;
                        
       					
       					$sql_bid ="SELECT * FROM tbl_model WHERE id=$item_id";
                        $row_bid = $con->query($sql_bid); 
                        $res_bid = $row_bid->fetch_object();
                        $bid = $res_bid->brand_id;
       					
       					
       					
       					 
       					//$sql2 = "INSERT INTO tbl_sinvoice_item (tbl_sinvoice_id, tbl_pinvoice_item, model_id, quantity, discount, base_price, hsn_rate, price)
       				//	VALUES  
       				   // ($tbl_sinvoice_id,0,$item_id,$item_qua,'0',$item_pp,$item_hsn,$item_amount)";
       				   
       				   $date = date('Y-m-d h:i:s', time());
       				   
       				$sql2 = "INSERT INTO tbl_pinvoic_item (invoice_id, brand_id, model_id, color_id, cmp_id, imei_no, quantity, base_price, hsn_rate, price, purchase_stock_status,purchase_date,stock_status,description,updated_at,deleted_at)
       					VALUES 
       					($tbl_sinvoice_id, $bid, $item_id, 4, $cmp_id, '', '$item_qua', '$item_rate', '$item_hsn', '$item_amount','1','$bill_date',1,'','$date','$date')";
       				   
                        if($con->query($sql2) === TRUE){
                           
                            
                        }
                        
                        echo $con->error;
                        
                     // echo   $sql2;
                        //////////////////////
                        
                      
                        $sql_ms = "SELECT * FROM tbl_model WHERE id=$item_id";
                        $row_ms = $con->query($sql_ms); 
                        $res_ms = $row_ms->fetch_object();
                        $model_stock = $res_ms->model_stock;
                      
                        $newStock = $model_stock + $item_qua;
                        
                        $sql_ms = "UPDATE tbl_model SET model_stock='$newStock' WHERE id='$item_id'";

                        if ($con->query($sql_ms) === TRUE) {
                            
                            
                            $su = 'Success';
                            
                        }else{
                             $su = 'False';
                        }
       					 
       					
       					
       					$sql_ad = "SELECT * FROM tbl_open_account_cv WHERE cv_id=$cus_id";
                        $row_ad = $con->query($sql_ad); 
                        $res_ad = $row_ad->fetch_object();
                        $total_amount = $res_ad->total_amount;
                        $paid_amount = $res_ad->paid_amount;
                        $dues_amount = $res_ad->dues_amount;
                        $available_amount = $res_ad->available_amount;
       					 
       					$new_total_amount = $total_amount + $total9;
       					$new_paid_amount = $paid_amount + $total_paid;
       					
       					$ss = $new_total_amount - $new_paid_amount;
       					$new_due_amount = $dues_amount + $ss;
       					 
       					 
       					$sql_acc = "UPDATE tbl_open_account_cv SET total_amount='$new_total_amount', paid_amount='$new_paid_amount', dues_amount='$new_due_amount', available_amount='$available_amount'  WHERE cv_id=$cus_id";

                        if ($con->query($sql_acc) === TRUE) {
                            
                            $saacu = 'Success';
                            
                        }else{
                            
                             $saacu = 'False';
                             
                        }
       			
       					 
    		     }
    		     
    		     
    		     
            //$sqlub="SELECT * FROM customers WHERE id=$cus_id && login_id=$login_id";
            //$rowub = $con->query($sqlub); 
            //$resub = $rowub->fetch_object();
            //$ub= $resub->wallet;
           
            
    		     
    		     
    		    $response["error"] = TRUE;
                $response["error_msg"] = "Success";
                $response["error_stocku_pdate"] = $su;
                $response["invoice_id"] = $tbl_sinvoice_id;
                echo json_encode(array("order"=>$response));
    		     
    		 }
    		 else{
    		    $response["error"] = FASLE;
               // $response["error_msg"] = $con->error;
                $response["error_msg"] = $con->error;
                echo json_encode(array("order"=>$response));
    		 }
        
    }else{
        
        $response["error"] = FALSE;
        $response["error_msg"] = "Bill No already exists";
        echo json_encode(array("order"=>$response));
        
        
       
            
 
}

 }
 else{
    $response["error"] = FALSE;
    $response["error_msg"] = "Auth Error";
    echo json_encode(array("order"=>$response));
 }


//mysqli_close($con);

?>