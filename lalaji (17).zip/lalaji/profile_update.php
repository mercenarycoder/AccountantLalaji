<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$user_id= $data_back->{"user_id"};


$name= $data_back->{"name"};
$role= $data_back->{"role"};
$email= $data_back->{"email"};
$password= $data_back->{"password"};
$mobile= $data_back->{"mobile"};
$address= $data_back->{"address"};
$state= $data_back->{"state"};
$city= $data_back->{"city"};

$response = array(); 

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    
       $sql = "UPDATE tbl_cmp_user_login SET user_name='$name', user_mobile='$mobile', user_address='$address', user_state='$state', user_city='$city' WHERE id='$user_id'";

            if ($con->query($sql) === TRUE) {
                
                
            }

                $response['error'] = TRUE;
                $response['error_msg'] = 'success';

                echo json_encode(array('profile_update'=>$response));
   
}
   
  ?>