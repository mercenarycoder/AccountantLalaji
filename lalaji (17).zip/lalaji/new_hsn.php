<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};
$hsn_desc = $data_back->{"hsn_desc"};
$hsn_rate = $data_back->{"hsn_rate"};
$hsn_code = $data_back->{"hsn_code"};

$response=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
    
    $date = date('Y-m-d h:i:s', time());
   
                $sql = "INSERT INTO tbl_hsn (login_id, cmp_id, hsn_description, hsn_rate, hsn_code,updated_at,deleted_at)
                VALUES
                ($login_id, $cmp_id , '$hsn_desc', '$hsn_rate', '$hsn_code','$date','$date')";
        
                    if ($con->query($sql) === TRUE) {
           
                        $response["error"]=TRUE;
                        $response["error_msg"]='Success';
                        echo json_encode(array("hsn"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("hsn"=>$response)); 

                        }
            
           

}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("hsn"=>$response));
}

    
    











?>