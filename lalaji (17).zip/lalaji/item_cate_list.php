<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$from= $data_back->{"from"};
$to= $data_back->{"to"};

$response = array(); 
$ProductArray = array();
$BrandArray = array();
$HSNArray = array();
$UnitArray = array();
$CastArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    if ($result4 = $con->query("SELECT tbl_model.*, tbl_brand.brand_name, tbl_hsn.hsn_rate,hsn_code FROM tbl_model 
        INNER JOIN tbl_brand ON tbl_model.brand_id = tbl_brand.id
        INNER JOIN tbl_hsn ON tbl_model.hsn_id = tbl_hsn.id WHERE tbl_model.cmp_id =$cmp_id && tbl_model.login_id =$login_id && tbl_model.model_status ='active' ORDER BY id DESC LIMIT $from,$to ")) {

            while($row4 = $result4->fetch_array(MYSQLI_ASSOC)) {
                        $ProductArray[] = $row4;
            }
                    
                    
                if ($result5 = $con->query("SELECT * FROM tbl_brand where login_id=$login_id and cmp_id=$cmp_id ORDER BY id DESC LIMIT $from,$to ")) {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $BrandArray[] = $row5;
                    }
                }
                
                if ($result6 = $con->query("SELECT * FROM tbl_hsn where login_id=$login_id and cmp_id=$cmp_id")) {

                    while($row6 = $result6->fetch_array(MYSQLI_ASSOC)) {
                        $HSNArray[] = $row6;
                    }
                }
                
                if ($result7 = $con->query("SELECT * FROM tbl_unit")) {

                    while($row7 = $result7->fetch_array(MYSQLI_ASSOC)) {
                        $UnitArray[] = $row7;
                    }
                }
                
                if ($result8 = $con->query("SELECT * FROM tbl_cast")) {

                    while($row8 = $result8->fetch_array(MYSQLI_ASSOC)) {
                        $CastArray[] = $row8;
                    }
                }
                    
                    
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                
            
                $response['item_array'] = $ProductArray;
                $response['brand_array'] = $BrandArray;
                $response['hsn_array'] = $HSNArray;
                $response['unit_array'] = $UnitArray;
                $response['cast_array'] = $CastArray;
               
                echo json_encode(array('item_cate_data'=>$response));
                
                }else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Failed';
                

                    echo json_encode(array('item_cate_data'=>$response));
                
                }
                
                
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('item_cate_data'=>$response));
                
                }
                
   
  ?>