<?php
 
 $host		= "localhost"; // Use Local Host Only      
$username	= "viasdigi_express";
$password	= "express@123"; 
$db_name	= "viasdigi_mobile_express"; 
 
$con = mysqli_connect($host, $username, $password, $db_name);
 
if (!$con) {
 echo "Connection Error". PHP_EOL;
 echo "Error Code: ". mysqli_connect_errno().PHP_EOL;
 echo "Error: Description".mysqli_connect_error().PHP_EOL;
 exit;
}




?>