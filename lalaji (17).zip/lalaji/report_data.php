<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};


$response = array(); 

$BrandArray = array();
$ModelArray = array();
$MOdeArray = array();



if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
   
                    
                if ($result5 = $con->query("SELECT * FROM tbl_brand where login_id=$login_id and cmp_id=$cmp_id")) {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $BrandArray[] = $row5;
                    }
                }
                
                  if ($result6 = $con->query("SELECT * FROM tbl_model where login_id=$login_id and cmp_id=$cmp_id")) {

                    while($row6 = $result6->fetch_array(MYSQLI_ASSOC)) {
                        $ModelArray[] = $row6;
                    }
                }
                
                if ($result7 = $con->query("SELECT * FROM tbl_account where login_id=$login_id and cmp_id=$cmp_id && account_type=2")) {

                    while($row7 = $result7->fetch_array(MYSQLI_ASSOC)) {
                        $MOdeArray[] = $row7;
                    }
                }
                
                    
                    
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                $response['brand_array'] = $BrandArray;
                $response['model_array'] = $ModelArray;
                $response['mode_array'] = $MOdeArray;
               
               
                echo json_encode(array('report_data'=>$response));
                
              
                
                
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('report_data'=>$response));
                
                }
                
   
  ?>