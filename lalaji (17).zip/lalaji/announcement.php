<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};

$login_id= $data_back->{"login_id"};

$response = array(); 

$hsnArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
                if ($result5 = $con->query("SELECT * FROM tbl_announcement where admin_id=$login_id and status='active' ORDER BY id DESC LIMIT 2 ")) {

                while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $hsnArray[] = $row5;
                }
               
              
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                
                $response['announcement_array'] = $hsnArray;
               
                echo json_encode(array('announcement_data'=>$response));
                
                }else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Failed';
                

                    echo json_encode(array('announcement_data'=>$response));
                
                }
                
                
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('announcement_data'=>$response));
                
                }
                
   
  ?>