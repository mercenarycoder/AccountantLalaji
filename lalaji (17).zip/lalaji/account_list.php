<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};

$response = array(); 

$hsnArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
   // SELECT tbl_model.*, tbl_brand.brand_name, tbl_hsn.hsn_rate,hsn_code FROM tbl_model 
            //    INNER JOIN tbl_brand ON tbl_model.brand_id = tbl_brand.id
          //      INNER JOIN tbl_hsn ON tbl_model.hsn_id = tbl_hsn.id WHERE tbl_model.cmp_id =$cmp_id && tbl_model.login_id =$login_id && tbl_model.model_status ='active'
          
           
                
                if ($result5 = $con->query("SELECT tbl_account.*, tbl_bank.bank_name FROM tbl_account
                INNER JOIN tbl_bank ON tbl_account.account_type = tbl_bank.id WHERE tbl_account.login_id =$login_id && tbl_account.cmp_id =$cmp_id")) {

                while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $hsnArray[] = $row5;
                }
               
              
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                
                $response['account_array'] = $hsnArray;
               
                echo json_encode(array('account_data'=>$response));
                
                }else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = $con->error;
                

                    echo json_encode(array('account_data'=>$response));
                
                }
                
                
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('account_data'=>$response));
                
                }
                
   
  ?>