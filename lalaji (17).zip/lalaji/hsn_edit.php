<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$id = $data_back->{"id"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};
$hsn_desc = $data_back->{"hsn_desc"};
$hsn_rate = $data_back->{"hsn_rate"};
$hsn_code = $data_back->{"hsn_code"};
$hsnID = $data_back->{"hsnID"};

$response=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
   
   $sql = "UPDATE tbl_hsn SET hsn_description='$hsn_desc', hsn_rate='$hsn_rate', hsn_code='$hsn_code' WHERE id=$hsnID ";


                    if ($con->query($sql) === TRUE) {
           
                        $response["error"]=TRUE;
                        $response["error_msg"]='Success';
                        echo json_encode(array("hsn"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("hsn"=>$response)); 

                        }
            
           

}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("hsn"=>$response));
}

    
    











?>