<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$created_by= $data_back->{"created_by"};
$from= $data_back->{"from"};
$to= $data_back->{"to"};


$response = array(); 
$SaleListArray = array();


if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    $todayDate = date("Y-m-d");
    
    if ($result_SL = $con->query("SELECT tbl_sinvoice.*, customers.customer_name,customer_mobile, tbl_account.account_name as mode  FROM tbl_sinvoice 
        INNER JOIN customers ON tbl_sinvoice.customer_id = customers.id
        INNER JOIN tbl_account ON tbl_sinvoice.payment_mode = tbl_account.id
        WHERE tbl_sinvoice.bill_date ='$todayDate' && tbl_sinvoice.cmp_id =$cmp_id && tbl_sinvoice.admin_id =$login_id && tbl_sinvoice.created_by =$created_by && tbl_sinvoice.status ='active' ORDER BY id DESC LIMIT $from,$to")) {

        while($row_SL = $result_SL->fetch_array(MYSQLI_ASSOC)) {
            $SaleListArray[] = $row_SL;
        }
        
        
        $sql_data="SELECT sum(`grand_total`) AS grand_total FROM `tbl_sinvoice` WHERE cmp_id=$cmp_id && admin_id =$login_id && bill_date ='$todayDate'";
        $row_data = $con->query($sql_data); 
        $res_data = $row_data->fetch_object();
        $grand_total= $res_data->grand_total;
        
        $sql_data2="SELECT COUNT(id) AS NumberOfRows FROM tbl_sinvoice WHERE cmp_id=$cmp_id && admin_id =$login_id && bill_date ='$todayDate'";
        $row_data2 = $con->query($sql_data2); 
        $res_data2 = $row_data2->fetch_object();
        $NumberOfRows= $res_data2->NumberOfRows;
        

        $response['error'] = TRUE;
        $response['error_msg'] = 'success';
        $response['today_amount'] = $grand_total;
        $response['today_bill'] = $NumberOfRows;
        
        $response['salelist_array'] = $SaleListArray;
        
        
        echo json_encode(array('salelist_data'=>$response));
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = 'Failed';
        echo json_encode(array('salelist_data'=>$response));
    }
     
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = 'Failed';
        echo json_encode(array('salelist_data'=>$response));
    }
?>