<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$type= $data_back->{"type"};
$from= $data_back->{"from"};
$to= $data_back->{"to"};

$response = array(); 
$CustomerArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    
    //  SELECT tbl_model.*, tbl_brand.brand_name, tbl_hsn.hsn_rate,hsn_code FROM tbl_model 
    //    INNER JOIN tbl_brand ON tbl_model.brand_id = tbl_brand.id
    //    INNER JOIN tbl_hsn ON tbl_model.hsn_id = tbl_hsn.id WHERE tbl_model.cmp_id =$cmp_id && tbl_model.login_id =$login_id && tbl_model.model_status ='active'
    
                
               // if ($result5 = $con->query("SELECT * FROM customers WHERE cmp_id=$cmp_id && login_id=$login_id && customer_type='$type' && status='active' ")) 
               
               if ($result5 = $con->query("SELECT customers.*, tbl_state.state_name FROM customers
               INNER JOIN tbl_state ON customers.state_id = tbl_state.id WHERE customers.cmp_id =$cmp_id && customers.login_id =$login_id && customers.customer_type ='$type' && customers.status ='active' ORDER BY id DESC LIMIT $from,$to")) 
               
                {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) 
                    {
                        $CustomerArray[] = $row5;
                    }
                    
                    
                    $response['error'] = TRUE;
                    $response['error_msg'] = 'success';
                
                    $response['customer_array'] = $CustomerArray;

                    echo json_encode(array('customer_data'=>$response));
                    
                }else
                {
    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Error';
                    echo json_encode(array('customer_data'=>$response));
  
                }

}else
{
    
                $response['error'] = FALSE;
                $response['error_msg'] = 'Auth Error';
                echo json_encode(array('customer_data'=>$response));
}
   
  ?>