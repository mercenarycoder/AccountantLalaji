<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};

$response = array(); 

$hsnArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
        $todayDate = date("Y-m-d");
    
    
        $sql_data="SELECT sum(`model_stock`) AS total_stock FROM `tbl_model` WHERE cmp_id=$cmp_id";
        $row_data = $con->query($sql_data); 
        $res_data = $row_data->fetch_object();
        $totalStock= $res_data->total_stock;
                
        $sql_sdata="SELECT sum(`grand_total`) AS totalAmount FROM `tbl_sinvoice` WHERE cmp_id=$cmp_id && bill_date='$todayDate'";
        $row_sdata = $con->query($sql_sdata); 
        $res_sdata = $row_sdata->fetch_object();
        $totalAmount= $res_sdata->totalAmount;
                
        $sql="SELECT id FROM tbl_sinvoice WHERE cmp_id=$cmp_id && bill_date='$todayDate' ORDER BY id";

        if ($result=mysqli_query($con,$sql))
        {
            
             $rowcount=mysqli_num_rows($result);
           
            mysqli_free_result($result);
        }
              
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                $response['totalStock'] = $totalStock;
                $response['totalAmount'] = $totalAmount;
                $response['totalSale'] = $rowcount;
           
               
                echo json_encode(array('drawer_data'=>$response));
                
               
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('drawer_data'=>$response));
                
                }
                
   
  ?>