<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};
$aname = $data_back->{"aname"};
$atype = $data_back->{"atype"};
$aopenamount = $data_back->{"aopenamount"};
$accid = $data_back->{"accid"};

$response=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
    
    
    $sql_st="SELECT * FROM tbl_bank WHERE bank_name	='$atype'";
    $row_st = $con->query($sql_st);
    $res_st = $row_st->fetch_object();
    $id = $res_st->id;
    
    
                
                 $sql = "UPDATE tbl_account SET opening_account='$aopenamount', account_type='$id', account_name='$aname' WHERE id=$accid ";
        
                    if ($con->query($sql) === TRUE) {
           
                        $response["error"]=TRUE;
                        $response["error_msg"]='Success';
                        echo json_encode(array("newaccount"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("newaccount"=>$response)); 

                        }
            
           

}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("newaccount"=>$response));
}

    
    











?>