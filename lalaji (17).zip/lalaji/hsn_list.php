<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};

$response = array(); 

$hsnArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
                
                if ($result5 = $con->query("SELECT * FROM tbl_hsn where login_id=$login_id and cmp_id=$cmp_id")) {

                while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) {
                        $hsnArray[] = $row5;
                }
               
              
                $response['error'] = TRUE;
                $response['error_msg'] = 'success';
                
                $response['hsn_array'] = $hsnArray;
               
                echo json_encode(array('hsn_data'=>$response));
                
                }else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Failed';
                

                    echo json_encode(array('hsn_data'=>$response));
                
                }
                
                
   
}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                

                    echo json_encode(array('hsn_data'=>$response));
                
                }
                
   
  ?>