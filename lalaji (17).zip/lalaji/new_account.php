<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key = $data_back->{"auth_key"};
$cmp_id = $data_back->{"cmp_id"};
$login_id = $data_back->{"login_id"};
$aname = $data_back->{"aname"};
$atype = $data_back->{"atype"};
$aopenamount = $data_back->{"aopenamount"};


$response=array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v"){
    
    
    $sql_st="SELECT * FROM tbl_bank WHERE bank_name	='$atype'";
    $row_st = $con->query($sql_st);
    $res_st = $row_st->fetch_object();
    $id = $res_st->id;
    
    
     $date = date('Y-m-d h:i:s', time());
    
   
                $sql = "INSERT INTO tbl_account (login_id, cmp_id, opening_account, account_type, account_name,updated_at,deleted_at)
                VALUES
                ($login_id, $cmp_id , $aopenamount, $id , '$aname','$date','$date')";
        
                    if ($con->query($sql) === TRUE) {
           
                        $response["error"]=TRUE;
                        $response["error_msg"]='Success';
                        echo json_encode(array("newaccount"=>$response));

           
                    } else {
                        $response["error"]=FALSE;
                        $response["error_msg"]= $con->error;
                        echo json_encode(array("newaccount"=>$response)); 

                        }
            
           

}else{
            $response["error"]=FALSE;
            $response["error_msg"]='Somthing went wrong !';
           // $response["error_msguu"]=$adds;
            echo json_encode(array("newaccount"=>$response));
}

    
    











?>