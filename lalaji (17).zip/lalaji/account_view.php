<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cv_id= $data_back->{"cv_id"};

$response = array(); 

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
            $sql_cv="SELECT * FROM tbl_open_account_cv WHERE cv_id=$cv_id";
            $row_cv = $con->query($sql_cv); 
            $res_cv = $row_cv->fetch_object();
            $cv_idd = $res_cv->cv_id;
            $total_amount = $res_cv->total_amount;
            $paid_amount = $res_cv->paid_amount;
            $dues_amount = $res_cv->dues_amount;
            $available_amount = $res_cv->available_amount;
            
            
                $response['error'] = TRUE;
                $response['error_msg'] = 'Success';
                 $response['cv_id'] = $cv_idd;
                  $response['total_amount'] = $total_amount;
                   $response['paid_amount'] = $paid_amount;
                    $response['dues_amount'] = $dues_amount;
                     $response['available_amount'] = $available_amount;
                     
                echo json_encode(array('account'=>$response));
                

}else{
                    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Auth Error';
                    echo json_encode(array('account'=>$response));
                
                }
                
   
  ?>