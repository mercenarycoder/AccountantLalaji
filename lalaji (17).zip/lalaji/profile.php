<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
// set json string to php variables
$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$user_id= $data_back->{"user_id"};

$response = array(); 
$CusArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
                if ($result3 = $con->query("SELECT * FROM tbl_cmp_user_login WHERE id =$user_id && user_status ='active'")) {

                    while($row3 = $result3->fetch_array(MYSQLI_ASSOC)) {
                        $CusArray[] = $row3;
                    }
                }
                

                $response['error'] = TRUE;
                $response['error_msg'] = 'success';

                $response['profile_array'] = $CusArray;

                echo json_encode(array('profile'=>$response));
   
}
   
  ?>