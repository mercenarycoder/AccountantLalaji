<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));
 
$auth_key= $data_back->{"auth_key"};

$response = array(); 
$AccountArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
                
                if ($result5 = $con->query("SELECT * FROM tbl_bank")) 
                {

                    while($row5 = $result5->fetch_array(MYSQLI_ASSOC)) 
                    {
                        $AccountArray[] = $row5;
                    }
                    
                    
                    $response['error'] = TRUE;
                    $response['error_msg'] = 'success';
                
                    $response['account_array'] = $AccountArray;

                    echo json_encode(array('account'=>$response));
                    
                }else
                {
    
                    $response['error'] = FALSE;
                    $response['error_msg'] = 'Error';
                    echo json_encode(array('account'=>$response));
  
                }

}else
{
    
                $response['error'] = FALSE;
                $response['error_msg'] = 'Auth Error';
                echo json_encode(array('account'=>$response));
}
   
  ?>