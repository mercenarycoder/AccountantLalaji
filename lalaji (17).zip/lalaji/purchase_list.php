<?php

include('config.php');

$data_back = json_decode(file_get_contents('php://input'));

$auth_key= $data_back->{"auth_key"};
$cmp_id= $data_back->{"cmp_id"};
$login_id= $data_back->{"login_id"};
$created_by= $data_back->{"created_by"};
$response = array(); 
$SaleListArray = array();

if($auth_key=="sujeet@#$%999drv$#@%!^se44vwx35v")
{
    
    if ($result_SL = $con->query("SELECT tbl_pinvoic.*, customers.customer_name,customer_mobile, tbl_account.account_name as mode  FROM tbl_pinvoic 
        INNER JOIN customers ON tbl_pinvoic.vendor_id = customers.id
        INNER JOIN tbl_account ON tbl_pinvoic.payment_mode = tbl_account.id
        WHERE tbl_pinvoic.cmp_id =$cmp_id && tbl_pinvoic.admin_id =$login_id && tbl_pinvoic.created_by =$created_by && tbl_pinvoic.status =1")) {

        while($row_SL = $result_SL->fetch_array(MYSQLI_ASSOC)) {
            $SaleListArray[] = $row_SL;
        }
        
        $response['error'] = TRUE;
        $response['error_msg'] = 'success';
        $response['purchaselist_array'] = $SaleListArray;
        echo json_encode(array('purchaselist_data'=>$response));
        
    }else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = $con->error;
        echo json_encode(array('purchaselist_data'=>$response));
    }
     
}else
    {
        $response['error'] = TRUE;
        $response['error_msg'] = 'Failed';
        echo json_encode(array('purchaselist_data'=>$response));
    }
      

?>